#!/bin/sh

yarn start
